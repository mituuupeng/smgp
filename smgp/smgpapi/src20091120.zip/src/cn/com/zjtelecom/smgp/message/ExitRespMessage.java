package cn.com.zjtelecom.smgp.message;

public class ExitRespMessage {
	public ExitRespMessage(byte[] buffer) {
		
	}
}
