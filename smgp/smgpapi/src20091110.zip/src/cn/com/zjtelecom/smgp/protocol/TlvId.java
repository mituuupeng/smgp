package cn.com.zjtelecom.smgp.protocol;

public class TlvId {
	public static int TP_pid = 0x0001;
	public static int TP_udhi = 0x0002;
	public static int LinkID = 0x0003;
	public static int ChargeUserType = 0x0004;
	public static int ChargeTermType = 0x0005;
	public static int ChargeTermPseudo = 0x0006;
	public static int DestTermType = 0x0007;
	public static int DestTermPseudo = 0x0008;
	public static int PkTotal = 0x0009;
	public static int PkNumber = 0x000A;
	public static int SubmitMsgType = 0x000B;
	public static int SPDealReslt = 0x000C;
	public static int SrcTermType = 0x000D;
	public static int SrcTermPseudo = 0x000E;
	public static int NodesCount = 0x000F;
	public static int MsgSrc = 0x0010;
	public static int SrcType = 0x0011;
	public static int Mserviceid = 0x0012;

}
